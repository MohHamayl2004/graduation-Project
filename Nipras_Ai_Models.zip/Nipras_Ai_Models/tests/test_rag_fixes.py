"""
Regression checks for the seven retrieval defects described in
docs/RAG_FIXES.md.

Run:  python tests/test_rag_fixes.py
No pytest or model download required.
"""

import sys
import os

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from rag.normalize import normalize, tokenize
from rag.chunker import create_chunks, get_overlap_units
from rag.retriever import passes_filter, maximal_marginal_relevance


failures = []


def check(name, condition, detail=""):
    status = "PASS" if condition else "FAIL"
    print(f"[{status}] {name}" + (f"  -- {detail}" if detail else ""))
    if not condition:
        failures.append(name)


# ---- 4. normalization is symmetric --------------------------------
for left, right in [
    ("الإقتران", "الاقتران"),
    ("مُتوسط التغيُّر", "متوسط التغير"),
    ("س٢", "س2"),
    ("ق(٢)", "ق(2)"),
]:
    check(
        f"normalize: {left!r} == {right!r}",
        normalize(left) == normalize(right),
    )

check(
    "normalize: Arabic maths gets a Latin copy",
    "f(x)" in normalize("ق(س) = س٣ - ٥س + ٣"),
)

check("tokenize returns tokens", len(tokenize(normalize("متوسط التغير"))) >= 2)


# ---- 1. overlap respects its budget -------------------------------
oversized = {
    "token_count": 420,
    "text": "x",
    "blocks": [],
    "block_types": [],
    "latex": [],
}

copied = sum(u["token_count"] for u in get_overlap_units([oversized], 50))

check(
    "overlap: oversized unit is not copied",
    copied <= 50,
    f"copied {copied} tokens with a 50 token budget",
)


# ---- 2/3. chunking keeps question and solution together -----------
document = {
    "source": "math_2026.pdf",
    "page_number": 4,
    "blocks": [
        {"order": 1, "type": "definition",
         "text": "متوسط التغير للاقتران ص = ق(س)"},
        {"order": 2, "type": "equation",
         "text": "Δص/Δس = (ق(س٢)-ق(س١))/(س٢-س١)", "latex": "d"},
        {"order": 3, "type": "example",
         "text": "مثال ١: ق(س) = س٣ - ٥س + ٣"},
        {"order": 4, "type": "text",
         "text": "١) Δس  ٢) التغير في ق(س)  ٣) متوسط التغير"},
        {"order": 5, "type": "solution",
         "text": "الحل: Δس = ٣ ، Δص = ⁻٦ ، متوسط التغير = ⁻٢"},
    ],
}

chunks = create_chunks(document, subject="math", lesson="1-1")
first = chunks[0]

check(
    "chunker: example and solution land in one chunk",
    "مثال" in first["text"] and "الحل" in first["text"],
)

check(
    "chunker: bridging block did not break the chain",
    "solution" in first["block_types"],
)

check("chunker: embedding_text present", bool(first.get("embedding_text")))

check("chunker: truncation_risk flag present", "truncation_risk" in first)


# ---- 5. metadata filter -------------------------------------------
check(
    "filter: keeps matching subject",
    passes_filter({"subject": "math"}, {"subject": "math"}),
)

check(
    "filter: rejects other subject",
    not passes_filter({"subject": "physics"}, {"subject": "math"}),
)

check(
    "filter: no filters means keep everything",
    passes_filter({"subject": "physics"}, None),
)


# ---- 5. MMR removes near duplicates -------------------------------
question = np.array([1.0, 0.0, 0.0])

candidates = np.array([
    [1.00, 0.00, 0.0],
    [0.99, 0.14, 0.0],   # near duplicate of the first
    [0.00, 1.00, 0.0],
])

selected = maximal_marginal_relevance(
    question, candidates, [0.99, 0.98, 0.60], 3
)

check(
    "MMR: near-duplicate candidate is dropped",
    1 not in selected,
    f"selected {selected}",
)


print()
if failures:
    print(f"{len(failures)} check(s) FAILED: {failures}")
    sys.exit(1)

print("All checks passed.")
