# ============================================================
# FileName: main.py
# Project: Nipras AI Tutor
# LastModifier: Tareq
# LastModifiedDate: 2026-08-18
#
# Purpose:
# Test Qwen3.6 document extraction on one mathematics PDF
# page, save the structured JSON result, and generate a clean
# TXT file from that JSON.
# ============================================================


from pathlib import Path
import json

from rag.vision_extractor import extract_page_with_qwen


# ============================================================
# Test Configuration
# ============================================================

# IMPORTANT:
# Change this path if your PDF has a different filename.
#
# Example:
#
# data/raw/lesson1.pdf
#
# or:
#
# data/raw/ma12-s.pdf

PDF_PATH = Path(
    "C:/Users/Tareq/OneDrive/Desktop/niprasProject/data/raw/math/lesson1.pdf"
)


# Test ONE PAGE first.
#
# If lesson1.pdf contains only the first lesson and starts
# directly with the Rate of Change page:
#
# PAGE_TO_TEST = 1
#
# If you are testing the complete original textbook, set this
# to the actual PDF page containing the lesson.

PAGE_TO_TEST = 1


# ============================================================
# Output Configuration
# ============================================================

OUTPUT_DIRECTORY = Path(
    "data/processed/qwen"
)


# ============================================================
# Function: save_structured_json
#
# Purpose:
# Save the structured document returned by Qwen.
#
# The JSON keeps:
# - source PDF
# - page number
# - model
# - document blocks
#
# Parameters:
# result:
#     Extraction result returned by vision_extractor.py.
#
# output_file:
#     JSON destination path.
# ============================================================

def save_structured_json(
    result,
    output_file,
):

    json_output = {

        "source":
            result["source"],

        "page_number":
            result["page_number"],

        "model":
            result["model"],

        "blocks":
            result["document"]["blocks"],
    }

    output_file.write_text(
        json.dumps(
            json_output,
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )


# ============================================================
# Function: save_clean_text
#
# Purpose:
# Save the clean plain text that was generated FROM the Qwen
# structured JSON.
#
# This TXT will later become the input to chunker.py.
#
# Parameters:
# text:
#     Clean educational text.
#
# output_file:
#     TXT destination path.
# ============================================================

def save_clean_text(
    text,
    output_file,
):

    output_file.write_text(
        text,
        encoding="utf-8",
    )


# ============================================================
# Main Program
# ============================================================

def main():

    # --------------------------------------------------------
    # Validate the input PDF before asking Qwen to run.
    # --------------------------------------------------------

    if not PDF_PATH.exists():

        print(
            "\nERROR:"
        )

        print(
            f"PDF was not found: {PDF_PATH}"
        )

        print(
            "\nCheck the PDF filename and its location "
            "inside data/raw."
        )

        return

    # --------------------------------------------------------
    # Create output directory.
    # --------------------------------------------------------

    OUTPUT_DIRECTORY.mkdir(
        parents=True,
        exist_ok=True,
    )

    # --------------------------------------------------------
    # Run Qwen extraction.
    # --------------------------------------------------------

    result = extract_page_with_qwen(
        pdf_path=PDF_PATH,
        page_number=PAGE_TO_TEST,
    )

    # --------------------------------------------------------
    # Output file paths.
    # --------------------------------------------------------

    json_file = (
        OUTPUT_DIRECTORY
        / f"page_{PAGE_TO_TEST}.json"
    )

    text_file = (
        OUTPUT_DIRECTORY
        / f"page_{PAGE_TO_TEST}.txt"
    )

    # --------------------------------------------------------
    # Save Qwen structured JSON.
    # --------------------------------------------------------

    save_structured_json(
        result=result,
        output_file=json_file,
    )

    # --------------------------------------------------------
    # Save clean TXT generated FROM JSON blocks.
    # --------------------------------------------------------

    save_clean_text(
        text=result["text"],
        output_file=text_file,
    )

    # --------------------------------------------------------
    # Show benchmark.
    # --------------------------------------------------------

    print("\n")
    print("=" * 60)
    print("NIPRAS QWEN3.6 EXTRACTION TEST")
    print("=" * 60)

    print(
        f"Source: {result['source']}"
    )

    print(
        f"Page: {result['page_number']}"
    )

    print(
        f"Model: {result['model']}"
    )

    print("\nPERFORMANCE")
    print("-" * 60)

    print(
        f"Total time: "
        f"{result['total_duration_seconds']:.2f} seconds"
    )

    print(
        f"Model load time: "
        f"{result['load_duration_seconds']:.2f} seconds"
    )

    print(
        f"Image/prompt processing: "
        f"{result['prompt_duration_seconds']:.2f} seconds"
    )

    print(
        f"Text generation: "
        f"{result['generation_duration_seconds']:.2f} seconds"
    )

    print(
        f"Input tokens: "
        f"{result['input_tokens']}"
    )

    print(
        f"Output tokens: "
        f"{result['output_tokens']}"
    )

    print("\nOUTPUT FILES")
    print("-" * 60)

    print(
        f"Structured JSON: {json_file}"
    )

    print(
        f"Clean TXT:      {text_file}"
    )

    print("\nExtraction completed successfully.")


# ============================================================
# Python Entry Point
# ============================================================

if __name__ == "__main__":
    main()