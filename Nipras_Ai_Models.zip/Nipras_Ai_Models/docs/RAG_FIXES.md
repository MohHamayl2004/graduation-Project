# RAG Retrieval Quality Fixes

Seven defects that caused the retriever to return wrong, duplicated or
incomplete material. Each one is described with how to reproduce it.

Run `python tests/test_rag_fixes.py` to verify all of them at once.

---

## 0. The retrieval half of the pipeline did not import

`config.py` was rewritten on 2026-08-18 with new constant names, but the
modules that consume it were not updated.

```
FAIL rag.retriever    -> ImportError: cannot import name 'TOP_K'
FAIL rag.rag_pipeline -> ImportError: cannot import name 'MINIMUM_SIMILARITY_SCORE'
FAIL rag.vector_store -> ImportError: cannot import name 'FAISS_INDEX_PATH'
FAIL rag.embedding_model -> ImportError: cannot import name 'EMBEDDING_MODEL_NAME'
```

**Fix:** added the missing constants plus aliases for the older path names.

---

## 1. Overlap copied an unbounded amount of text

`get_overlap_units()` only enforced the size limit once something had
already been selected:

```python
if (selected_units and token_count + unit["token_count"] > overlap_size):
    break
```

On the first iteration `selected_units` is empty, so the guard
short-circuits and the unit is appended regardless of size.

| overlap budget | last unit | copied (before) | copied (after) |
|---|---|---|---|
| 50 tokens | 420 tokens | **420** | 0 |

The next chunk therefore started 8x above `chunk_size`, and a complete
worked example appeared in two chunks. With `top_k` results that meant
the same example occupying two slots.

**Fix:** the budget is enforced on every iteration.

---

## 2. Solutions were separated from their questions

`should_keep_together()` stopped at the first block whose type was not in
`KEEP_TOGETHER_RULES`. The ministry book is laid out as:

```
example  ->  (question parts 1,2,3)  ->  solution
```

The middle block has type `text`, which is not a related type, so the
chain broke there and the solution became an orphan chunk with no
question attached to it.

**Fix:** a short block (<= `BRIDGE_MAX_CHARS`) may be bridged when a
related block follows it.

---

## 3. Long chunks were silently truncated at embedding time

`estimate_token_count()` counts one token per Arabic word. Real
sub-word tokenizers produce 2-4x more. A chunk measured as "300 tokens"
can be 900 real tokens, past the model's 512 limit, and
sentence-transformers cuts the remainder **without any warning**.

The tail is present in `metadata.json` but is not in the vector, so it
can never be retrieved.

**Fix:** `EMBEDDING_MAX_TOKENS` is set explicitly on the model, and every
chunk carries a `truncation_risk` flag.

---

## 4. No normalization on either side

Nothing normalized Arabic text at index time or query time, so these did
not match despite being identical in meaning:

| written one way | written another way | cause |
|---|---|---|
| `الإقتران` | `الاقتران` | alef forms |
| `س٢` | `س2` | Arabic-Indic digits |
| `مُتوسط` | `متوسط` | harakat |
| `ق(س)` | `f(x)` | Arabic vs Latin notation |

**Fix:** new `rag/normalize.py`. It is called **inside** `EmbeddingModel`
on both the document path and the query path, so it cannot be forgotten.
E5 `query:` / `passage:` prefixes were also added.

---

## 5. No metadata filter and no diversity control

`retrieve()` returned the first `top_k` FAISS hits directly. A maths
question could retrieve physics chunks, and the same example appearing in
the textbook, the helper book and a past exam could take all three slots.

**Fix:**

```
question -> normalize -> metadata filter -> 30 candidates
         -> MMR diversity -> top_k
```

---

## 6. The similarity threshold reported but did not filter

When `best_score` fell below `MINIMUM_SIMILARITY_SCORE` the function
returned `found: False` **together with the weak results**. Anything
placed in the prompt gets used, so the tutor answered confidently from
unrelated material.

**Fix:** weak results move to a separate `rejected` field and never reach
the prompt.

---

## 7. No guard against vector/metadata drift

FAISS returns positions that are looked up in the `chunks` list. If the
two ever differ in length, every answer is built from the **wrong**
chunk. Nothing crashes and the answer still reads plausibly - the most
dangerous failure mode in a RAG system.

**Fix:** `retrieve()` raises immediately if
`index.ntotal != len(chunks)`.

---

## Still to do

`MINIMUM_SIMILARITY_SCORE = 0.55` is a **guess**. Calibrate it:

```bash
python -m rag.eval_retrieval --sweep
```

`data/eval/questions.json` currently holds 4 starter questions, including
one that is deliberately unanswerable ("What is the capital of Japan?")
to check that the system refuses rather than invents. Expand it to 20-50
real Tawjihi questions, then set the threshold between `mean_hit_score`
and `mean_miss_score`.
