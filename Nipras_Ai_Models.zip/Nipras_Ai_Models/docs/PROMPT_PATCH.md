# تعديل TRANSCRIPTION_PROMPT

الصق هذا داخل `rag/vision_extractor.py`، بعد قسم `MATHEMATICS RULES`
مباشرة (بعد البند 10 وقبل `BLOCK CLASSIFICATION`).

هذه القواعد الأربع تعالج أخطاء رصدناها فعلياً في مخرجات
`qwen3-vl:30b-a3b-instruct` على الصفحة الأولى من كتاب الرياضيات.

```python
============================================================
CRITICAL: TEXT DIRECTION
============================================================

Arabic must be written in LOGICAL order - the order the words
would be typed or spoken - NOT in the visual left-to-right
order the glyphs appear in on the page.

Correct:   متوسط التغير
Wrong:     ريغتلا طسوتم

If you output the second form, the transcription is unusable.

============================================================
CRITICAL: NEGATIVE NUMBERS
============================================================

This textbook marks a negative number with a RAISED minus
placed BEFORE the digit:

    ⁻١    means  negative one
    ⁻٦    means  negative six

This is NOT decoration and NOT a footnote marker. It changes
the value of the number.

Always transcribe it as a minus sign attached to the number:

    ⁻١  ->  "-١"
    ⁻٦  ->  "-٦"

NEVER drop it. A dropped sign turns a correct solution into a
wrong one, and nothing downstream can detect the error.

Check every result line of every solution for a raised minus
before you finish.

============================================================
CRITICAL: EXPONENTS AND INDICES
============================================================

Distinguish carefully between a raised digit (an exponent) and
a lowered digit (an index):

    س٣  raised   ->  write as  س^٣    (س cubed)
    س١  lowered  ->  write as  س_١    (س sub 1)

Read the exponent digit carefully. ٢ and ٣ are easy to confuse
at small sizes; zoom into the character before deciding.

============================================================
READING ORDER WITHIN A PAGE
============================================================

Follow the page's educational reading order, not the raw
position of text boxes:

- Arabic flows right to left, top to bottom.
- A label in the right margin (نشاط ١، مثال ١، الحل) belongs
  WITH the block it labels, as the beginning of that block -
  not as a separate block.
- Keep a numbered list item's number at the START of its item.
```

## بعد التعديل

أعد تشغيل الصفحة نفسها وقارن:

```powershell
python -m rag.benchmark_vision --models qwen3-vl:30b-a3b-instruct --dpi 150 --timeout 1800 --pdf data\raw\math\lesson1.pdf --page 1
```

إذا اختفى القلب في الاتجاه، فلن تحتاج `bidi_repair` أصلاً - وهي تبقى
كشبكة أمان لأن النموذج قد يعود للسلوك القديم في صفحة أخرى.
