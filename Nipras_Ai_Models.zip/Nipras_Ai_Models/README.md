# Nipras_Ai_Models
Here we are going to add our models
