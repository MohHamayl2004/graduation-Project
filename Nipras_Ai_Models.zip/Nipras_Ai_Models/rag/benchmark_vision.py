# ============================================================
# FileName: benchmark_vision.py
# Project: Nipras AI Tutor
#
# Purpose:
# Choose the vision model with measurements instead of guesses.
#
# The trade-off is speed against transcription accuracy, and it
# depends on this machine and on this textbook - not on any
# published benchmark. This script runs each candidate on the
# same page, times it, and scores the output against the
# human-checked reference in data/eval/.
#
# Usage:
#     ollama pull qwen3-vl:4b-instruct
#     ollama pull qwen3-vl:8b-instruct
#
#     python -m rag.benchmark_vision \
#         --models qwen3-vl:4b-instruct qwen3-vl:8b-instruct \
#         --pdf data/raw/math/lesson1.pdf --page 1
#
# Read the result as pages-per-hour against fact coverage.
# A model that is twice as fast but drops a minus sign is not
# a bargain - a wrong sign becomes a wrong explanation for a
# student.
# ============================================================


import json
import time
import argparse
from pathlib import Path

from rag import vision_extractor
from rag.validate_extraction import validate
from rag.config import PROJECT_ROOT


DEFAULT_REFERENCE = (
    PROJECT_ROOT / "data" / "eval" / "reference_lesson1_page1.json"
)

OUTPUT_DIRECTORY = PROJECT_ROOT / "data" / "processed" / "benchmark"


# ============================================================
# Function: run_one
# ============================================================

def run_one(model_name, pdf_path, page_number, reference_path,
            dpi=None, timeout=None):

    # The extractor reads the model name from its module-level
    # constant, so we swap it for the duration of the run.
    original = vision_extractor.VISION_MODEL_NAME

    vision_extractor.VISION_MODEL_NAME = model_name

    started = time.time()

    error = None

    document = None

    try:
        document = vision_extractor.extract_page_with_qwen(
            pdf_path,
            page_number,
            dpi=dpi,
            timeout=timeout,
        )

    except Exception as exception:
        error = f"{type(exception).__name__}: {exception}"

    finally:
        vision_extractor.VISION_MODEL_NAME = original

    elapsed = round(time.time() - started, 1)

    result = {
        "model": model_name,
        "dpi": dpi or vision_extractor.PAGE_DPI,
        "seconds": elapsed,
        "pages_per_hour": (
            round(3600 / elapsed, 1) if elapsed > 0 and not error else None
        ),
        "error": error,
    }

    if error:
        return result

    OUTPUT_DIRECTORY.mkdir(parents=True, exist_ok=True)

    output_path = (
        OUTPUT_DIRECTORY
        / f"{model_name.replace(':', '_').replace('/', '_')}"
          f"_dpi{dpi or vision_extractor.PAGE_DPI}"
          f"_page{page_number}.json"
    )

    output_path.write_text(
        json.dumps(document, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    result["output"] = str(output_path)

    report = validate(output_path, reference_path)

    result["blocks"] = report["extracted_blocks"]

    result["block_count_delta"] = report.get("block_count_delta")

    result["fact_coverage"] = report.get("fact_coverage")

    result["missing_facts"] = report.get("missing_facts", [])

    result["unclear_blocks"] = len(report["audit"]["unclear"])

    return result


# ============================================================
# Function: estimate_book
#
# Purpose:
# Translate seconds-per-page into the number that actually
# decides the plan: how long the whole book takes.
# ============================================================

def estimate_book(seconds_per_page, total_pages):

    hours = seconds_per_page * total_pages / 3600

    return round(hours, 1)


def main():

    parser = argparse.ArgumentParser()
    parser.add_argument("--models", nargs="+", required=True)
    parser.add_argument(
        "--dpi",
        nargs="+",
        type=int,
        default=[None],
        help="One or more render resolutions to sweep. Lower DPI means "
             "far fewer vision tokens and a much faster page on CPU - "
             "the question is whether small indices like س_1 survive.",
    )
    parser.add_argument(
        "--timeout",
        type=int,
        default=None,
        help="Seconds before giving up on one page.",
    )
    parser.add_argument("--pdf", default="data/raw/math/lesson1.pdf")
    parser.add_argument("--page", type=int, default=1)
    parser.add_argument("--reference", default=str(DEFAULT_REFERENCE))
    parser.add_argument(
        "--book-pages",
        type=int,
        default=250,
        help="Used only to project the full-book time.",
    )
    args = parser.parse_args()

    reference = args.reference if Path(args.reference).exists() else None

    if not reference:
        print(
            "No reference file - timing only, accuracy will not "
            "be scored.\n"
        )

    results = []

    for model_name in args.models:

        for dpi in args.dpi:

            label = f"{model_name} @ {dpi or 'default'} DPI"

            print(f"\n=== {label} ===", flush=True)

            result = run_one(
                model_name, args.pdf, args.page, reference,
                dpi=dpi, timeout=args.timeout,
            )

            results.append(result)

            print(json.dumps(result, ensure_ascii=False, indent=2), flush=True)

    print("\n" + "=" * 62)
    print(f"{'model':26} {'dpi':>5} {'sec/page':>9} {'coverage':>9} {'book(h)':>8}")
    print("-" * 62)

    for result in results:

        if result.get("error"):
            print(
                f"{result['model']:26} {result.get('dpi', '-'):>5} "
                f"{'FAILED':>9}"
            )
            continue

        coverage = result.get("fact_coverage")

        print(
            f"{result['model']:26} "
            f"{result.get('dpi', '-'):>5} "
            f"{result['seconds']:>9.1f} "
            f"{(f'{coverage:.0%}' if coverage is not None else '-'):>9} "
            f"{estimate_book(result['seconds'], args.book_pages):>8}"
        )

    print("=" * 62)
    print(
        "\nPick on coverage first, speed second. A dropped sign or "
        "digit becomes a wrong explanation for a student, and no "
        "later stage of the pipeline can detect it."
    )


if __name__ == "__main__":
    main()
