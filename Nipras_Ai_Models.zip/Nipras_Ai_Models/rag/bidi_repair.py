# ============================================================
# FileName: bidi_repair.py
# Project: Nipras AI Tutor
#
# Purpose:
# Repair Arabic that a vision model transcribed in VISUAL order
# instead of LOGICAL order.
#
# The symptom looks catastrophic but is not: the model read the
# page correctly and simply wrote the characters out in the
# order they appear left-to-right on screen.
#
#   raw     "ريغتلا طسوتم ١ - ١"
#   fixed   "١ - ١ متوسط التغير"
#
# One rule matters: digit runs and Latin runs must NOT be
# reversed internally. "٥٢" reversed becomes "٢٥" - fifty-two
# silently turns into twenty-five, and no later stage can tell.
# ============================================================


import re


# Brackets swap sides when the string is reversed.
MIRROR = {
    "(": ")", ")": "(",
    "[": "]", "]": "[",
    "{": "}", "}": "{",
    "<": ">", ">": "<",
    "«": "»", "»": "«",
}

# Runs that keep their internal order.
ATOMIC = re.compile(
    r"[0-9٠-٩]+(?:[.,،][0-9٠-٩]+)?"          # numbers, incl. decimals
    r"|[A-Za-z]+(?:[ \-][A-Za-z]+)*"          # Latin PHRASES, not just words
)

ARABIC = re.compile(r"[؀-ۿ]")

# Frequent Arabic words. They only appear when the text is in
# logical order, which makes them a reliable direction signal.
MARKERS = [
    "في", "من", "على", "إلى", "التي", "الذي", "هذا", "هذه",
    "كان", "إذا", "أن", "عند", "بين", "مع", "كل",
    "متوسط", "التغير", "الحل", "مثال", "تعريف", "نشاط",
    "يساوي", "الاقتران", "جد", "احسب", "حيث", "ونرمز",
]


# ============================================================
# Function: reverse_visual
# ============================================================

def reverse_visual(text):

    tokens = []

    last = 0

    for match in ATOMIC.finditer(text):

        tokens.extend(text[last:match.start()])

        tokens.append(match.group(0))

        last = match.end()

    tokens.extend(text[last:])

    return "".join(
        token if len(token) > 1 else MIRROR.get(token, token)
        for token in reversed(tokens)
    )


# ============================================================
# Function: direction_score
# ============================================================

def direction_score(text):
    return sum(text.count(marker) for marker in MARKERS)


# ============================================================
# Function: page_is_visual_order
#
# Purpose:
# Decide direction ONCE for the whole page, not per block.
#
# A short block ("الحل", a bare equation) carries no marker
# words, so judging it alone is unreliable. The vision model is
# consistent within a page, so the page-level verdict is applied
# to every block.
# ============================================================

def page_is_visual_order(blocks):

    joined = " ".join(
        str(block.get("text", ""))
        for block in blocks
    )

    if not ARABIC.search(joined):
        return False

    return direction_score(reverse_visual(joined)) > direction_score(joined)


# ============================================================
# Function: repair_document
#
# Purpose:
# Fix every block of a page in place and report what happened.
#
# Returns (document, report).
# ============================================================

def repair_document(document):

    blocks = document.get("blocks", [])

    if not blocks:
        return document, {"repaired": False, "blocks": 0}

    if not page_is_visual_order(blocks):
        return document, {"repaired": False, "blocks": len(blocks)}

    changed = 0

    for block in blocks:

        for field in ("text", "latex"):

            value = block.get(field)

            if value and ARABIC.search(str(value)):
                block[field] = reverse_visual(str(value))
                changed += 1

    if isinstance(document.get("text"), str) and ARABIC.search(document["text"]):
        document["text"] = "\n\n".join(
            reverse_visual(part)
            for part in document["text"].split("\n\n")
        )

    return document, {
        "repaired": True,
        "blocks": len(blocks),
        "fields": changed,
    }


# ============================================================
# Function: repair_text
# ============================================================

def repair_text(text):

    if not text or not ARABIC.search(text):
        return text, False

    flipped = reverse_visual(text)

    if direction_score(flipped) > direction_score(text):
        return flipped, True

    return text, False
