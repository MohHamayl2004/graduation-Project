# ============================================================
# FileName: eval_retrieval.py
# Project: Nipras AI Tutor
#
# Purpose:
# Measure retrieval quality instead of guessing at it.
#
# Every number in config.py - chunk_size, overlap, top_k and
# especially MINIMUM_SIMILARITY_SCORE - is a guess until it is
# measured against real questions. This script turns those
# guesses into numbers.
#
# Usage:
#     python -m rag.eval_retrieval
#     python -m rag.eval_retrieval --k 3 --subject math
#
# Input:
#     data/eval/questions.json
#
#     [
#       {
#         "question": "كيف احسب متوسط التغير؟",
#         "expect_keywords": ["متوسط التغير", "Δص"],
#         "subject": "math"
#       }
#     ]
#
# "expect_keywords" is the cheap form of ground truth: a chunk
# counts as correct when it contains all of them (after
# normalization). Use "expect_chunk_ids" once chunk ids are
# stable for a precise measurement.
# ============================================================


import json
import argparse
from pathlib import Path

from rag.config import PROJECT_ROOT, TOP_K, MINIMUM_SIMILARITY_SCORE
from rag.normalize import normalize


EVAL_QUESTIONS_PATH = PROJECT_ROOT / "data" / "eval" / "questions.json"


# ============================================================
# Function: is_relevant
# ============================================================

def is_relevant(result, case):

    expected_ids = case.get("expect_chunk_ids")

    if expected_ids:
        return result.get("chunk_id") in expected_ids

    keywords = case.get("expect_keywords", [])

    if not keywords:
        return False

    haystack = normalize(result.get("text", ""))

    return all(
        normalize(keyword) in haystack
        for keyword in keywords
    )


# ============================================================
# Function: evaluate
#
# Purpose:
# Run every evaluation question and report the metrics that
# actually matter for a RAG system.
#
# recall@k:
#     Did the correct material appear anywhere in the top k?
#     If this is low, chunking or embedding is the problem -
#     no amount of prompt engineering will fix it.
#
# MRR:
#     How high up did it appear? Rewards putting the right
#     chunk first.
#
# score separation:
#     The gap between hit scores and miss scores. This is what
#     MINIMUM_SIMILARITY_SCORE should sit inside. If the two
#     distributions overlap, no threshold can separate
#     "answerable" from "not in the book".
# ============================================================

def evaluate(pipeline, cases, k=None):

    k = k or TOP_K

    hits = 0

    reciprocal_ranks = []

    hit_scores = []

    miss_scores = []

    failures = []

    for case in cases:

        filters = {}

        if case.get("subject"):
            filters["subject"] = case["subject"]

        response = pipeline.search(
            case["question"],
            filters=filters or None,
            top_k=k,
        )

        results = response["results"] or response.get("rejected", [])

        found_rank = None

        for result in results:

            if is_relevant(result, case):
                found_rank = result["rank"]
                hit_scores.append(result["score"])
                break

        if found_rank:
            hits += 1
            reciprocal_ranks.append(1.0 / found_rank)
        else:
            reciprocal_ranks.append(0.0)
            if results:
                miss_scores.append(results[0]["score"])
            failures.append(case["question"])

    total = len(cases) or 1

    def average(values):
        return round(sum(values) / len(values), 4) if values else None

    return {
        "questions": len(cases),
        "k": k,
        f"recall@{k}": round(hits / total, 4),
        "mrr": round(sum(reciprocal_ranks) / total, 4),
        "mean_hit_score": average(hit_scores),
        "mean_miss_score": average(miss_scores),
        "current_threshold": MINIMUM_SIMILARITY_SCORE,
        "failures": failures,
    }


# ============================================================
# Function: sweep
#
# Purpose:
# Compare several k values in one run so top_k is chosen from
# evidence rather than habit.
# ============================================================

def sweep(pipeline, cases, k_values=(1, 3, 5, 10)):

    return [
        evaluate(pipeline, cases, k=k)
        for k in k_values
    ]


def main():

    parser = argparse.ArgumentParser()
    parser.add_argument("--k", type=int, default=None)
    parser.add_argument("--sweep", action="store_true")
    parser.add_argument(
        "--questions",
        default=str(EVAL_QUESTIONS_PATH),
    )
    args = parser.parse_args()

    path = Path(args.questions)

    if not path.exists():
        raise SystemExit(
            f"No evaluation set at {path}.\n"
            "Create it with 20-50 real Tawjihi questions before "
            "tuning any retrieval parameter."
        )

    cases = json.loads(path.read_text(encoding="utf-8"))

    from rag.rag_pipeline import RAGPipeline

    pipeline = RAGPipeline()

    if args.sweep:
        for report in sweep(pipeline, cases):
            print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        print(
            json.dumps(
                evaluate(pipeline, cases, k=args.k),
                ensure_ascii=False,
                indent=2,
            )
        )


if __name__ == "__main__":
    main()
