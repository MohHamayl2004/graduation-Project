# ============================================================
# FileName: rag_pipeline.py
# Project: Nipras AI Tutor
# LastModifier: Tareq
# LastModifiedDate: 2026-08-15
#
# Purpose:
# Combine the different RAG components into one simple service.
#
#
# Question
#    ↓
# Embedding Model
#    ↓
# FAISS
#    ↓
# Retrieval
#    ↓
# Relevance Check
# ============================================================


from rag.embedding_model import EmbeddingModel

from rag.vector_store import load_vector_store

from rag.retriever import retrieve

from rag.config import MINIMUM_SIMILARITY_SCORE


# ============================================================
# Class: RAGPipeline
#
# Purpose:
# Provide one clean interface for searching the Nipras
# knowledge base.
# ============================================================

class RAGPipeline:


    # ========================================================
    # Function: __init__
    #
    # Purpose:
    # Load the embedding model and vector database once when
    # the RAG system starts.
    # ========================================================

    def __init__(self):


        # ----------------------------------------------------
        # self.embedding_model
        #
        # Meaning:
        # Embedding model used for student questions.
        # ----------------------------------------------------

        self.embedding_model = EmbeddingModel()


        # ----------------------------------------------------
        # self.index
        #
        # Meaning:
        # Loaded FAISS vector database.
        #
        # self.chunks
        #
        # Meaning:
        # Original lesson chunks and their metadata.
        # ----------------------------------------------------

        self.index, self.chunks = load_vector_store()


    # ========================================================
    # Function: search
    #
    # Purpose:
    # Search lesson material for information relevant to a
    # student's question.
    #
    #
    # Parameter:
    #
    # question:
    #     Student question.
    #
    #
    # Return:
    #
    # Dictionary containing:
    #
    # found:
    #     Whether enough relevant information was found.
    #
    # best_score:
    #     Similarity score of the best result.
    #
    # results:
    #     Retrieved lesson chunks.
    # ========================================================

    def search(self, question, filters=None, top_k=None):


        results = retrieve(
            question,
            self.embedding_model,
            self.index,
            self.chunks,
            filters=filters,
            top_k=top_k,
        )


        # No results were found.
        if not results:

            return {
                "found": False,
                "best_score": 0.0,
                "results": []
            }


        # ----------------------------------------------------
        # best_score
        #
        # Meaning:
        # Highest similarity score because FAISS returns
        # results ordered from best to worst.
        # ----------------------------------------------------

        best_score = results[0]["score"]


        # ----------------------------------------------------
        # Check whether the best result is relevant enough.
        # ----------------------------------------------------

        if (
            best_score
            < MINIMUM_SIMILARITY_SCORE
        ):

            # ------------------------------------------------
            # Nothing relevant. Return NO results at all.
            #
            # The previous version still handed the weak chunks
            # back. Anything placed in the prompt gets used, so
            # the tutor would answer confidently from unrelated
            # material instead of saying the book does not
            # cover it.
            # ------------------------------------------------

            return {
                "found": False,
                "best_score": best_score,
                "results": [],
                "rejected": results,
            }


        # ----------------------------------------------------
        # Drop the weak tail as well. A strong first result
        # does not make results 4 and 5 relevant.
        # ----------------------------------------------------

        kept = [
            result
            for result in results
            if result["score"] >= MINIMUM_SIMILARITY_SCORE
        ]


        return {
            "found": True,
            "best_score": best_score,
            "results": kept,
            "rejected": [
                result
                for result in results
                if result["score"] < MINIMUM_SIMILARITY_SCORE
            ],
        }