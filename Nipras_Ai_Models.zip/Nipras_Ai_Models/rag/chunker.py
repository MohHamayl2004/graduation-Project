# ============================================================
# FileName: chunker.py
# Project: Nipras AI Tutor
# LastModifier: Tareq
# LastModifiedDate: 2026-08-18
#
# Purpose:
# Convert structured lesson content extracted by Qwen into
# meaningful RAG chunks while preserving educational
# relationships such as:
#
# definition + equation
# example + solution
# rule + equation
#
# The chunker also supports configurable chunk size and
# overlap values from rag/config.py.
# ============================================================


import re

from rag.config import (
    KEEP_TOGETHER_RULES,
    get_chunking_profile,
    EMBEDDING_MAX_TOKENS,
    TOKEN_ESTIMATE_SAFETY_FACTOR,
)

from rag.normalize import normalize


# Maximum size of a non-related block that may be pulled in to
# bridge a question and its solution.
BRIDGE_MAX_CHARS = 400


# ============================================================
# Function: estimate_token_count
#
# Purpose:
# Estimate how many token-like units exist in a text.
#
# IMPORTANT:
# This is currently an approximation.
#
# Later, after the Nipras embedding model is finalized, this
# function should use the tokenizer belonging to that exact
# embedding model.
#
# Parameters:
# text:
#     Input text.
#
# Return:
# Estimated token count.
# ============================================================

def estimate_token_count(text):

    if not text:
        return 0

    # --------------------------------------------------------
    # Split Arabic/English words, numbers, and mathematical
    # symbols into token-like units.
    #
    # This is more useful than simply counting spaces, but it
    # is still NOT the final embedding-model tokenizer.
    # --------------------------------------------------------

    tokens = re.findall(
        r"[\u0600-\u06FF]+"
        r"|[A-Za-z]+"
        r"|\d+(?:\.\d+)?"
        r"|[^\s]",
        text,
    )

    return len(tokens)


# ============================================================
# Function: block_to_text
#
# Purpose:
# Extract useful educational text from one Qwen document block.
#
# The normal readable "text" field is preferred.
#
# If the text field is empty for an equation, the LaTeX field
# is used as a fallback.
#
# Parameters:
# block:
#     One block from the Qwen JSON.
#
# Return:
# Clean block text.
# ============================================================

def block_to_text(block):

    block_text = str(
        block.get(
            "text",
            ""
        )
    ).strip()

    # --------------------------------------------------------
    # Equation fallback.
    # --------------------------------------------------------

    if not block_text:

        latex = str(
            block.get(
                "latex",
                ""
            )
        ).strip()

        if latex:
            block_text = latex

    return block_text


# ============================================================
# Function: should_keep_together
#
# Purpose:
# Determine whether two neighboring educational blocks should
# stay together whenever possible.
#
# Example:
#
# definition + equation
# example + solution
#
# Parameters:
# current_type:
#     Type of the current block.
#
# next_type:
#     Type of the following block.
#
# Return:
# True if the blocks should stay together.
# ============================================================

def should_keep_together(
    current_type,
    next_type,
):

    allowed_following_types = (
        KEEP_TOGETHER_RULES.get(
            current_type,
            set(),
        )
    )

    return (
        next_type
        in allowed_following_types
    )


# ============================================================
# Function: create_semantic_units
#
# Purpose:
# Group related Qwen blocks before creating final chunks.
#
# This prevents important educational structures from being
# separated unnecessarily.
#
# Example:
#
# Block 1: definition
# Block 2: equation
#
# becomes:
#
# Semantic Unit:
# definition + equation
#
# Parameters:
# blocks:
#     Ordered Qwen document blocks.
#
# Return:
# List of semantic units.
# ============================================================

def create_semantic_units(blocks):

    if not blocks:
        return []

    # --------------------------------------------------------
    # Always preserve Qwen reading order.
    # --------------------------------------------------------

    ordered_blocks = sorted(
        blocks,
        key=lambda block: block.get(
            "order",
            999999,
        ),
    )

    semantic_units = []

    index = 0

    while index < len(ordered_blocks):

        current_block = ordered_blocks[index]

        current_text = block_to_text(
            current_block
        )

        current_type = str(
            current_block.get(
                "type",
                "other",
            )
        ).strip()

        # Ignore completely empty blocks.
        if not current_text:
            index += 1
            continue

        unit_blocks = [
            current_block
        ]

        unit_text_parts = [
            current_text
        ]

        # ----------------------------------------------------
        # Check whether the next block is educationally
        # connected to the current block.
        # ----------------------------------------------------

        next_index = index + 1

        while next_index < len(ordered_blocks):

            next_block = (
                ordered_blocks[next_index]
            )

            next_type = str(
                next_block.get(
                    "type",
                    "other",
                )
            ).strip()

            previous_type = str(
                unit_blocks[-1].get(
                    "type",
                    "other",
                )
            ).strip()

            # ------------------------------------------------
            # Determine connection.
            #
            # We check the original starting block AND the
            # previous block.
            #
            # This allows:
            #
            # example
            #   ↓
            # equation
            #   ↓
            # solution
            # ------------------------------------------------

            related_to_start = (
                should_keep_together(
                    current_type,
                    next_type,
                )
            )

            related_to_previous = (
                should_keep_together(
                    previous_type,
                    next_type,
                )
            )

            # ------------------------------------------------
            # BUG FIX:
            # The chain used to break on the FIRST unrelated
            # block. In the ministry book an example is often
            # written as:
            #
            #   example  ->  (question parts 1,2,3)  ->  solution
            #
            # The middle text is not in KEEP_TOGETHER_RULES, so
            # the loop stopped there and the solution became an
            # orphan chunk with no question attached.
            #
            # We now allow a short bridging block to be pulled
            # in, as long as a related block follows it.
            # ------------------------------------------------

            if not (
                related_to_start
                or related_to_previous
            ):

                bridge_text = block_to_text(
                    next_block
                )

                following_related = False

                if (
                    len(bridge_text) <= BRIDGE_MAX_CHARS
                    and next_index + 1 < len(ordered_blocks)
                ):

                    following_type = str(
                        ordered_blocks[
                            next_index + 1
                        ].get(
                            "type",
                            "other",
                        )
                    ).strip()

                    following_related = (
                        should_keep_together(
                            current_type,
                            following_type,
                        )
                        or should_keep_together(
                            previous_type,
                            following_type,
                        )
                    )

                if not following_related:
                    break

            next_text = block_to_text(
                next_block
            )

            if next_text:

                unit_blocks.append(
                    next_block
                )

                unit_text_parts.append(
                    next_text
                )

            next_index += 1

        unit_text = "\n\n".join(
            unit_text_parts
        )

        unit_block_types = [
            str(
                block.get(
                    "type",
                    "other",
                )
            )
            for block in unit_blocks
        ]

        unit_latex = [
            str(
                block.get(
                    "latex",
                    ""
                )
            ).strip()
            for block in unit_blocks
            if str(
                block.get(
                    "latex",
                    ""
                )
            ).strip()
        ]

        semantic_units.append(
            {
                "text": unit_text,

                "token_count":
                    estimate_token_count(
                        unit_text
                    ),

                "blocks":
                    unit_blocks,

                "block_types":
                    unit_block_types,

                "latex":
                    unit_latex,
            }
        )

        # Continue after all blocks that were consumed.
        index = next_index

    return semantic_units


# ============================================================
# Function: get_overlap_units
#
# Purpose:
# Select semantic units from the END of the previous chunk
# that should be repeated at the beginning of the next chunk.
#
# This implements the RAG overlap.
#
# Parameters:
# chunk_units:
#     Units currently stored in the previous chunk.
#
# overlap_size:
#     Approximate number of tokens to repeat.
#
# Return:
# List of semantic units used as overlap.
# ============================================================

def get_overlap_units(
    chunk_units,
    overlap_size,
):

    if (
        overlap_size <= 0
        or not chunk_units
    ):
        return []

    selected_units = []

    token_count = 0

    # --------------------------------------------------------
    # Start from the END of the chunk.
    # --------------------------------------------------------

    for unit in reversed(
        chunk_units
    ):

        # ----------------------------------------------------
        # BUG FIX:
        # The previous version only enforced the size limit
        # when at least one unit had already been selected.
        # On the FIRST iteration the guard short-circuited, so
        # a single large unit (a full example + solution) was
        # copied whole no matter how small overlap_size was.
        #
        # The next chunk then started already far above
        # chunk_size, and the same example appeared in two
        # chunks - which is how near-duplicate results ended up
        # filling top_k.
        #
        # An overlap unit is now only accepted if it actually
        # fits inside the requested overlap budget.
        # ----------------------------------------------------
        if (
            token_count
            + unit["token_count"]
            > overlap_size
        ):
            break

        selected_units.append(
            unit
        )

        token_count += (
            unit["token_count"]
        )

        if token_count >= overlap_size:
            break

    # Reverse back into normal reading order.
    selected_units.reverse()

    return selected_units


# ============================================================
# Function: build_chunk
#
# Purpose:
# Convert semantic units into the final chunk dictionary.
#
# Parameters:
# units:
#     Semantic units inside the chunk.
#
# chunk_id:
#     Sequential chunk identifier.
#
# source:
#     Source PDF filename.
#
# page_number:
#     Source page number when available.
#
# subject:
#     Subject name.
#
# lesson:
#     Lesson name or identifier.
#
# Return:
# Final chunk dictionary.
# ============================================================

def build_chunk(
    units,
    chunk_id,
    source=None,
    page_number=None,
    subject=None,
    lesson=None,
):

    chunk_text = "\n\n".join(
        unit["text"]
        for unit in units
        if unit["text"]
    ).strip()

    block_types = []

    equations_latex = []

    for unit in units:

        for block_type in unit[
            "block_types"
        ]:

            if block_type not in block_types:
                block_types.append(
                    block_type
                )

        for latex in unit["latex"]:

            if latex not in equations_latex:
                equations_latex.append(
                    latex
                )

    # --------------------------------------------------------
    # embedding_text
    #
    # The normalized copy that is actually embedded and
    # searched. "text" stays raw so the student still sees the
    # original Arabic with its diacritics and notation.
    #
    # Indexing and querying MUST both go through
    # rag.normalize.normalize - see that module's golden rule.
    # --------------------------------------------------------

    embedding_text = normalize(
        chunk_text
    )

    estimated_tokens = estimate_token_count(
        chunk_text
    )

    # --------------------------------------------------------
    # truncation_risk
    #
    # sentence-transformers silently cuts anything past the
    # model's max sequence length. A chunk over the budget is
    # therefore only PARTLY searchable, and the missing tail
    # never appears in results even though it sits in the JSON.
    # --------------------------------------------------------

    truncation_risk = (
        estimated_tokens * TOKEN_ESTIMATE_SAFETY_FACTOR
        > EMBEDDING_MAX_TOKENS
    )

    return {
        "chunk_id": chunk_id,

        "text": chunk_text,

        "embedding_text": embedding_text,

        "token_count": estimated_tokens,

        "truncation_risk": truncation_risk,

        "source": source,

        "page_number": page_number,

        "subject": subject,

        "lesson": lesson,

        "block_types":
            block_types,

        # Keep LaTeX as metadata.
        #
        # It is NOT duplicated inside the embedding text.
        "equations_latex":
            equations_latex,
    }


# ============================================================
# Function: create_chunks
#
# Purpose:
# Convert structured page JSON into RAG chunks.
#
# Parameters:
# document_data:
#     Parsed JSON dictionary produced from Qwen.
#
# subject:
#     Subject name such as "math".
#
# lesson:
#     Optional lesson name.
#
# Return:
# List of RAG chunk dictionaries.
# ============================================================

def create_chunks(
    document_data,
    subject="math",
    lesson=None,
):

    if not isinstance(
        document_data,
        dict
    ):
        raise TypeError(
            "document_data must be a dictionary."
        )

    blocks = document_data.get(
        "blocks",
        []
    )

    if not isinstance(
        blocks,
        list
    ):
        raise ValueError(
            "'blocks' must be a list."
        )

    if not blocks:
        return []

    # --------------------------------------------------------
    # Get subject profile.
    # --------------------------------------------------------

    profile = get_chunking_profile(
        subject
    )

    chunk_size = profile[
        "chunk_size"
    ]

    overlap_size = profile[
        "overlap"
    ]

    # --------------------------------------------------------
    # Document metadata.
    # --------------------------------------------------------

    source = document_data.get(
        "source"
    )

    page_number = document_data.get(
        "page_number"
    )

    # --------------------------------------------------------
    # Build semantic units first.
    # --------------------------------------------------------

    semantic_units = (
        create_semantic_units(
            blocks
        )
    )

    chunks = []

    current_units = []

    current_token_count = 0

    chunk_id = 1

    for unit in semantic_units:

        unit_token_count = (
            unit["token_count"]
        )

        # ----------------------------------------------------
        # If the current chunk is empty, always accept the unit.
        #
        # This prevents an oversized definition/example from
        # being silently lost.
        # ----------------------------------------------------

        if not current_units:

            current_units.append(
                unit
            )

            current_token_count = (
                unit_token_count
            )

            continue

        # ----------------------------------------------------
        # Check whether adding the next semantic unit would
        # exceed the configured chunk size.
        # ----------------------------------------------------

        projected_size = (
            current_token_count
            + unit_token_count
        )

        if projected_size <= chunk_size:

            current_units.append(
                unit
            )

            current_token_count = (
                projected_size
            )

            continue

        # ----------------------------------------------------
        # Current chunk is full.
        # Save it.
        # ----------------------------------------------------

        chunks.append(
            build_chunk(
                units=current_units,
                chunk_id=chunk_id,
                source=source,
                page_number=page_number,
                subject=subject,
                lesson=lesson,
            )
        )

        chunk_id += 1

        # ----------------------------------------------------
        # Prepare overlap for the next chunk.
        # ----------------------------------------------------

        overlap_units = (
            get_overlap_units(
                current_units,
                overlap_size,
            )
        )

        current_units = (
            overlap_units.copy()
        )

        current_token_count = sum(
            overlap_unit[
                "token_count"
            ]
            for overlap_unit
            in current_units
        )

        # ----------------------------------------------------
        # Add the new unit.
        # ----------------------------------------------------

        current_units.append(
            unit
        )

        current_token_count += (
            unit_token_count
        )

    # --------------------------------------------------------
    # Save the final unfinished chunk.
    # --------------------------------------------------------

    if current_units:

        chunks.append(
            build_chunk(
                units=current_units,
                chunk_id=chunk_id,
                source=source,
                page_number=page_number,
                subject=subject,
                lesson=lesson,
            )
        )

    return chunks