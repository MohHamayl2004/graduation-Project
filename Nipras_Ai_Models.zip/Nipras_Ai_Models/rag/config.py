# ============================================================
# FileName: config.py
# Project: Nipras AI Tutor
# LastModifier: Tareq
# LastModifiedDate: 2026-08-18
#
# Purpose:
# Store the central configuration used by the Nipras RAG
# system, including data paths, chunking settings, retrieval
# settings, and subject-specific RAG profiles.
# ============================================================


import os

from pathlib import Path


# ============================================================
# Vision Extraction Model
# ============================================================

# The team default. Tareq runs this one; it is the accuracy target.
#
# Override per machine WITHOUT editing this shared file:
#
#   PowerShell   $env:NIPRAS_VISION_MODEL = "qwen3-vl:8b-instruct"
#   bash         export NIPRAS_VISION_MODEL=qwen3-vl:8b-instruct
#
# A weaker machine can drop to 8b locally while the repository keeps
# pointing at the model the extracted corpus is actually built with.
VISION_MODEL_NAME = os.getenv(
    "NIPRAS_VISION_MODEL",
    "qwen3-vl:30b-a3b-instruct",
)

# ============================================================
# Project Paths
# ============================================================

# niprasProject/
PROJECT_ROOT = Path(__file__).resolve().parent.parent


# niprasProject/data/
DATA_DIRECTORY = PROJECT_ROOT / "data"


# Original PDFs and lesson material.
RAW_DATA_DIRECTORY = DATA_DIRECTORY / "raw"


# Extracted JSON/TXT files.
PROCESSED_DATA_DIRECTORY = DATA_DIRECTORY / "processed"


# Vector database directory.
VECTOR_DATABASE_DIRECTORY = PROJECT_ROOT / "vector_db"


# FAISS index file.
VECTOR_INDEX_PATH = (
    VECTOR_DATABASE_DIRECTORY
    / "nipras.index"
)


# Metadata connected to the FAISS vectors.
VECTOR_METADATA_PATH = (
    VECTOR_DATABASE_DIRECTORY
    / "metadata.json"
)


# ============================================================
# Default RAG Configuration
# ============================================================

# These settings are used when a subject does not have
# a specific profile.
#
# IMPORTANT:
# These values are starting points.
# They must later be evaluated using real retrieval questions.

DEFAULT_CHUNKING_PROFILE = {
    "chunk_size": 300,
    "overlap": 50,
    "top_k": 3,
}


# ============================================================
# Subject-Specific Profiles
# ============================================================

# We currently define a Math profile because Math is the first
# subject being implemented in Nipras.
#
# Other subjects will use DEFAULT_CHUNKING_PROFILE until testing
# proves that they need different settings.

CHUNKING_PROFILES = {

    "math": {
        "chunk_size": 300,
        "overlap": 50,
        "top_k": 3,
    },

}


# ============================================================
# Structure-Aware Chunking Rules
# ============================================================

# These block relationships should stay together whenever
# possible.
#
# Examples:
#
# definition
#     ↓
# equation
#
# example
#     ↓
# solution
#
# rule
#     ↓
# equation

KEEP_TOGETHER_RULES = {

    "definition": {
        "equation"
    },

    "rule": {
        "equation"
    },

    "example": {
        "equation",
        "solution",
    },

    "exercise": {
        "equation",
        "solution",
    },

    "activity": {
        "equation",
        "solution",
    },
}


# ============================================================
# Function: get_chunking_profile
#
# Purpose:
# Return the RAG chunking configuration for a subject.
#
# If no subject-specific configuration exists, the default
# configuration is returned.
#
# Parameters:
# subject:
#     Subject name such as "math" or "science".
#
# Return:
# Dictionary containing:
# - chunk_size
# - overlap
# - top_k
# ============================================================

def get_chunking_profile(subject=None):

    if not subject:
        return DEFAULT_CHUNKING_PROFILE.copy()

    normalized_subject = (
        str(subject)
        .strip()
        .lower()
    )

    profile = CHUNKING_PROFILES.get(
        normalized_subject,
        DEFAULT_CHUNKING_PROFILE,
    )

    # Return a copy so other modules cannot accidentally
    # modify the global configuration.
    return profile.copy()

# ============================================================
# Embedding Model
# ============================================================

# Multilingual model with Arabic support.
# NOTE: must be evaluated against alternatives before final use.
EMBEDDING_MODEL_NAME = "intfloat/multilingual-e5-base"

# Hard limit of the embedding model. Text longer than this is
# SILENTLY TRUNCATED by sentence-transformers, which means the
# tail of an oversized chunk never becomes searchable.
# Chunk budgets below are derived from this value.
EMBEDDING_MAX_TOKENS = 512

# Arabic is split into several sub-word tokens per word, so a
# word-ish count under-estimates the real tokenizer by 2-4x.
# We keep a safety factor when converting our estimate.
TOKEN_ESTIMATE_SAFETY_FACTOR = 2.5


# ============================================================
# Retrieval Configuration
# ============================================================

# Number of chunks finally passed to the AI Tutor.
TOP_K = 5

# How many candidates to pull from FAISS before diversity
# filtering and re-ranking. Must be >= TOP_K.
CANDIDATE_K = 30

# Below this similarity we treat the material as "not found"
# and instruct the tutor to say so instead of inventing.
# MUST be calibrated with rag/eval_retrieval.py - do not trust
# this default.
MINIMUM_SIMILARITY_SCORE = 0.55

# Maximal Marginal Relevance trade-off.
# 1.0 = pure similarity, 0.0 = pure diversity.
# Prevents three near-identical chunks filling the context.
MMR_LAMBDA = 0.65

# Two chunks more similar than this are considered duplicates
# and only the higher scoring one is kept.
DUPLICATE_SIMILARITY = 0.95


# ============================================================
# Backwards-compatible path aliases
# ============================================================
# vector_store.py was written against the older names.

VECTOR_DB_FOLDER = VECTOR_DATABASE_DIRECTORY
FAISS_INDEX_PATH = VECTOR_INDEX_PATH
METADATA_PATH = VECTOR_METADATA_PATH


# ============================================================
# Embedding Prefixes
# ============================================================
# E5-family models are trained with asymmetric prefixes.
# Omitting them measurably degrades retrieval quality.
# Set both to "" for a model that does not use prefixes.

QUERY_PREFIX = "query: "
PASSAGE_PREFIX = "passage: "
