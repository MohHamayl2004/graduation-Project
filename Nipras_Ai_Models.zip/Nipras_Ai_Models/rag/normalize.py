# ============================================================
# FileName: normalize.py
# Project: Nipras AI Tutor
#
# Purpose:
# Normalize Arabic educational text before it is embedded.
#
# THE GOLDEN RULE:
# The SAME function must be applied to lesson chunks at index
# time and to the student question at query time. Any
# difference between the two produces vectors that do not
# match, which shows up as silently wrong retrieval.
#
# Without this layer, all of the following fail to match even
# though they mean exactly the same thing:
#
#   "الاقتران"      vs  "الإقتران"       (alef forms)
#   "س٢"            vs  "س2"             (Arabic-Indic digits)
#   "مُتوسط"        vs  "متوسط"          (harakat)
#   "ق(س)"          vs  "f(x)"           (Arabic math notation)
# ============================================================

import re
import unicodedata


# ============================================================
# Character classes
# ============================================================

HARAKAT = re.compile(r"[ؐ-ًؚ-ٰٟۖ-ۭ]")

TATWEEL = "ـ"

ARABIC_INDIC_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩", "0123456789")

EXTENDED_ARABIC_DIGITS = str.maketrans("۰۱۲۳۴۵۶۷۸۹", "0123456789")

LETTER_FOLDING = str.maketrans({
    "أ": "ا", "إ": "ا", "آ": "ا", "ٱ": "ا",
    "ى": "ي", "ئ": "ي",
    "ؤ": "و",
    "ة": "ه",
    "ک": "ك", "ی": "ي",
    "‌": "", "‍": "", "‎": "", "‏": "",
    "‪": "", "‫": "", "‬": "",
})

SYMBOL_FOLDING = {
    "−": "-", "–": "-", "—": "-", "⁻": "-", "ـ": "",
    "×": "*", "÷": "/", "٫": ".", "٬": ",",
    "٪": "%", "،": ",", "؛": ";", "؟": "?",
    "«": '"', "»": '"', "“": '"', "”": '"', "’": "'",
    " ": " ",
}

SUPERSCRIPTS = {"⁰":"0","¹":"1","²":"2","³":"3","⁴":"4",
                "⁵":"5","⁶":"6","⁷":"7","⁸":"8","⁹":"9"}

SUBSCRIPTS = {"₀":"0","₁":"1","₂":"2","₃":"3","₄":"4",
              "₅":"5","₆":"6","₇":"7","₈":"8","₉":"9"}


# ============================================================
# Arabic mathematical notation
# ============================================================
# The Tawjihi book writes mathematics with Arabic letters, but
# language models learned mathematics in Latin notation. We
# index BOTH forms so a question written either way matches.

MATH_FUNCTIONS = [
    ("جتا", "cos"), ("ظتا", "cot"), ("قتا", "csc"),
    ("جا", "sin"), ("ظا", "tan"), ("قا", "sec"),
    ("نها", "lim"), ("لو", "log"),
]

MATH_VARIABLES = {
    "س": "x", "ص": "y", "ع": "z",
    "ق": "f", "هـ": "h", "ن": "n",
    "ф": "s",
}

# A symbol only counts as a mathematical variable when it sits
# next to mathematical punctuation - never inside a normal word.
MATH_CONTEXT = re.compile(
    r"(?:(?<=[\s\(\[=+\-*/^_0-9])|^)"
    r"(هـ|[سصعقن])"
    r"(?=\s*(?:[\(\)\[\]=+\-*/^_0-9]|$))"
)


# ============================================================
# Function: strip_diacritics
# ============================================================

def strip_diacritics(text):
    text = HARAKAT.sub("", text)
    return text.replace(TATWEEL, "")


# ============================================================
# Function: normalize_digits
# ============================================================

def normalize_digits(text):
    return text.translate(ARABIC_INDIC_DIGITS).translate(EXTENDED_ARABIC_DIGITS)


# ============================================================
# Function: normalize_symbols
# ============================================================

def normalize_symbols(text):
    for source, target in SYMBOL_FOLDING.items():
        text = text.replace(source, target)

    # Unicode powers and indices become explicit so that the
    # tokenizer cannot confuse س² (a power) with س₂ (an index).
    for source, target in SUPERSCRIPTS.items():
        text = text.replace(source, "^" + target)

    for source, target in SUBSCRIPTS.items():
        text = text.replace(source, "_" + target)

    return text


# ============================================================
# Function: fold_letters
# ============================================================

def fold_letters(text):
    return text.translate(LETTER_FOLDING)


# ============================================================
# Function: latinize_math
#
# Purpose:
# Produce a Latin-notation copy of any mathematics found in the
# text. This is APPENDED to the chunk rather than replacing it,
# so the original Arabic is still shown to the student.
# ============================================================

def latinize_math(text):
    for arabic, latin in MATH_FUNCTIONS:
        text = text.replace(arabic, latin)

    text = MATH_CONTEXT.sub(
        lambda m: MATH_VARIABLES.get(m.group(1), m.group(1)),
        text,
    )

    return text


# ============================================================
# Function: collapse_whitespace
# ============================================================

def collapse_whitespace(text):
    text = re.sub(r"[ \t​]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return "\n".join(line.strip() for line in text.split("\n")).strip()


# ============================================================
# Function: normalize
#
# Purpose:
# THE function. Call this - and only this - from both the
# indexing path and the query path.
#
# Parameters:
# text:
#     Raw Arabic educational text or student question.
#
# add_latin_math:
#     Append a Latin-notation copy of the mathematics so that
#     "ق(س)" and "f(x)" retrieve each other.
#
# Return:
# Normalized text ready for embedding and lexical search.
# ============================================================

def normalize(text, add_latin_math=True):

    if not text:
        return ""

    text = unicodedata.normalize("NFKC", str(text))
    text = strip_diacritics(text)
    text = normalize_symbols(text)
    text = normalize_digits(text)
    text = fold_letters(text)
    text = collapse_whitespace(text)

    if add_latin_math:
        latin = latinize_math(text)
        if latin != text:
            text = text + "\n" + latin

    return text


# ============================================================
# Function: clean_pdf_noise
#
# Purpose:
# Remove repeated headers, footers and standalone page numbers.
#
# Repeated noise makes every chunk look similar to every other
# chunk, which flattens the vector space and degrades ranking.
# ============================================================

def clean_pdf_noise(text, minimum_repetitions=3):

    if not text:
        return ""

    lines = text.split("\n")

    occurrences = {}

    for line in lines:
        stripped = line.strip()
        if 0 < len(stripped) <= 60:
            occurrences[stripped] = occurrences.get(stripped, 0) + 1

    noise = {
        line
        for line, count in occurrences.items()
        if count >= minimum_repetitions
    }

    kept = []

    for line in lines:
        stripped = line.strip()

        if stripped in noise:
            continue

        if re.fullmatch(r"[\-–—•\s]*[0-9٠-٩]{1,4}[\-–—•\s]*", stripped):
            continue

        kept.append(line)

    return collapse_whitespace("\n".join(kept))


# ============================================================
# Function: tokenize
#
# Purpose:
# Word tokenization for lexical (BM25) search. Runs on text
# that has ALREADY been normalized.
# ============================================================

TOKEN_PATTERN = re.compile(r"[A-Za-zء-ي0-9_^]+")

def tokenize(text):
    return TOKEN_PATTERN.findall(text or "")
