# ============================================================
# FileName: vector_store.py
# Project: Nipras AI Tutor
# LastModifier: Tareq
# LastModifiedDate: 2026-08-15
#
# Purpose:
# Create, save, and load the FAISS vector database.
#
#
# FAISS stores:
#     numerical embedding vectors.
#
# metadata.json stores:
#     original text
#     PDF source
#     page number
# ============================================================


import json

import faiss

from rag.config import (
    VECTOR_DB_FOLDER,
    FAISS_INDEX_PATH,
    METADATA_PATH
)


# ============================================================
# Function: create_vector_store
#
# Purpose:
# Create a FAISS index and add lesson embedding vectors.
#
#
# Parameter:
#
# embeddings:
#     Embedding vectors generated from lesson chunks.
#
#
# Return:
#
# index:
#     FAISS vector index.
# ============================================================

def create_vector_store(embeddings):


    # --------------------------------------------------------
    # Check that embeddings exist.
    # --------------------------------------------------------

    if len(embeddings) == 0:

        raise ValueError(
            "Cannot create FAISS index because no embeddings exist."
        )


    # --------------------------------------------------------
    # dimension
    #
    # Meaning:
    # Number of numerical values inside each embedding.
    #
    # Example:
    #
    # embeddings.shape = (50, 384)
    #
    # 50:
    #     number of chunks
    #
    # 384:
    #     embedding dimension
    # --------------------------------------------------------

    dimension = embeddings.shape[1]


    # --------------------------------------------------------
    # index
    #
    # Meaning:
    # FAISS vector database.
    #
    # IndexFlatIP uses inner-product similarity.
    #
    # Since our embeddings are normalized, inner product works
    # similarly to cosine similarity.
    # --------------------------------------------------------

    index = faiss.IndexFlatIP(
        dimension
    )


    # Add all vectors to the database.
    index.add(
        embeddings
    )


    return index


# ============================================================
# Function: save_vector_store
#
# Purpose:
# Save FAISS and its chunk metadata to disk.
#
#
# Parameters:
#
# index:
#     FAISS index.
#
# chunks:
#     Original text chunks and metadata.
# ============================================================

def save_vector_store(index, chunks):


    # --------------------------------------------------------
    # Create vector_db folder if it does not already exist.
    # --------------------------------------------------------

    VECTOR_DB_FOLDER.mkdir(
        parents=True,
        exist_ok=True
    )


    # --------------------------------------------------------
    # Save FAISS vectors.
    # --------------------------------------------------------

    faiss.write_index(
        index,
        str(FAISS_INDEX_PATH)
    )


    # --------------------------------------------------------
    # Save metadata.
    #
    # ensure_ascii=False keeps Arabic characters readable in
    # the JSON file.
    # --------------------------------------------------------

    with open(
        METADATA_PATH,
        "w",
        encoding="utf-8"
    ) as metadata_file:

        json.dump(
            chunks,
            metadata_file,
            ensure_ascii=False,
            indent=4
        )


    print(
        "Vector database saved successfully."
    )


# ============================================================
# Function: load_vector_store
#
# Purpose:
# Load the already-created FAISS database and metadata.
#
# This means we do NOT have to process all PDFs again whenever
# a student asks a question.
#
#
# Return:
#
# index:
#     FAISS vector database.
#
# chunks:
#     Text and metadata connected to the vectors.
# ============================================================

def load_vector_store():


    # --------------------------------------------------------
    # Check that ingestion has already been performed.
    # --------------------------------------------------------

    if not FAISS_INDEX_PATH.exists():

        raise FileNotFoundError(
            "FAISS database was not found. "
            "Run the ingestion script first."
        )


    if not METADATA_PATH.exists():

        raise FileNotFoundError(
            "Metadata file was not found. "
            "Run the ingestion script first."
        )


    # Load FAISS vectors.
    index = faiss.read_index(
        str(FAISS_INDEX_PATH)
    )


    # Load chunk metadata.
    with open(
        METADATA_PATH,
        "r",
        encoding="utf-8"
    ) as metadata_file:

        chunks = json.load(
            metadata_file
        )


    return index, chunks