# ============================================================
# FileName: vision_extractor.py
# Project: Nipras AI Tutor
# LastModifier: Tareq
# LastModifiedDate: 2026-08-18
#
# Purpose:
# Extract structured Arabic and mathematical content from
# textbook PDF pages using the Qwen3.6 vision model through
# Ollama.
#
# Workflow:
# PDF Page
#     ↓
# Render page as PNG in memory
#     ↓
# Convert PNG to Base64
#     ↓
# Send image + strict transcription prompt to Qwen3.6
#     ↓
# Receive structured JSON
#     ↓
# Convert JSON blocks into clean plain text
# ============================================================


from pathlib import Path
import base64
import json

import pymupdf
import requests

from rag.config import VISION_MODEL_NAME

from rag.bidi_repair import repair_document

# ============================================================
# Ollama Configuration
# ============================================================

OLLAMA_URL = "http://localhost:11434/api/generate"



# Render resolution.
#
# 220 DPI is a reasonable starting point for textbook pages.
# Later we can compare 200 / 250 / 300 DPI if equations are
# still difficult for the vision model.
PAGE_DPI = 220

# Qwen context size.
#
# Your previous Ollama configuration was 4096.
# We are testing 8192 for document extraction.
CONTEXT_SIZE = 8192

# Qwen is currently running on CPU on your machine,
# so one page may take several minutes.
REQUEST_TIMEOUT_SECONDS = 1200


# ============================================================
# Allowed document block types
# ============================================================

BLOCK_TYPES = [
    "heading",
    "paragraph",
    "activity",
    "definition",
    "rule",
    "example",
    "exercise",
    "solution",
    "equation",
    "note",
    "list_item",
    "table",
    "figure_caption",
    "other",
]


# ============================================================
# Structured JSON Schema
#
# Purpose:
# Tell Ollama/Qwen exactly what JSON structure must be returned.
#
# Every block always contains:
#
# order
# type
# text
# latex
#
# latex should be an empty string for normal text blocks.
# ============================================================

OUTPUT_SCHEMA = {
    "type": "object",
    "properties": {
        "blocks": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "order": {
                        "type": "integer"
                    },
                    "type": {
                        "type": "string",
                        "enum": BLOCK_TYPES
                    },
                    "text": {
                        "type": "string"
                    },
                    "latex": {
                        "type": "string"
                    }
                },
                "required": [
                    "order",
                    "type",
                    "text",
                    "latex"
                ],
                "additionalProperties": False
            }
        }
    },
    "required": [
        "blocks"
    ],
    "additionalProperties": False
}


# ============================================================
# Transcription Prompt
#
# Purpose:
# Force Qwen to behave as a document transcription system,
# not as a tutor or summarizer.
# ============================================================

TRANSCRIPTION_PROMPT = """
You are a strict document transcription system specialized in
Arabic mathematics textbooks.

Your task is to transcribe EVERY visible educational element
from the provided textbook page accurately and completely.

You are NOT a tutor in this task.
You are NOT solving the page.
You are ONLY extracting and structuring its visible content.

============================================================
GENERAL TRANSCRIPTION RULES
============================================================

1. Transcribe ALL visible educational content on the page.

2. Do NOT summarize.

3. Do NOT explain anything.

4. Do NOT solve exercises.

5. Do NOT correct the author's wording.

6. Do NOT add information that is not visible on the page.

7. Do NOT omit text because you think it is unimportant.

8. Preserve the original reading order:
   - Arabic is read from right to left.
   - Process the page from top to bottom.

9. Preserve Arabic words exactly as they appear.

10. Preserve all numbers exactly.

11. Preserve all:
    - headings
    - lesson titles
    - activities
    - definitions
    - rules
    - examples
    - exercises
    - solutions
    - notes
    - questions
    - list items
    - mathematical expressions

12. Decorative shapes that contain no educational information
    may be ignored.

13. If something is genuinely unreadable, write:
    [UNCLEAR]

14. Never invent or guess unreadable content.

============================================================
MATHEMATICS RULES
============================================================

Mathematical accuracy is extremely important.

For every mathematical expression:

1. Preserve every:
   - number
   - variable
   - operator
   - exponent
   - fraction
   - root
   - parenthesis
   - equality sign
   - inequality sign
   - Delta symbol
   - function notation

2. Do NOT simplify an equation.

3. Do NOT solve an equation.

4. Do NOT change mathematical notation.

5. Never mix LaTeX commands directly inside an Arabic
   paragraph.

6. Mathematical expressions should be separate equation
   blocks whenever possible.

7. Every equation block must contain TWO versions:

   text:
   A human-readable Unicode representation.

   latex:
   A LaTeX representation of exactly the same mathematical
   expression.

Example:

{
  "order": 5,
  "type": "equation",
  "text": "متوسط التغير = Δص / Δس",
  "latex": "\\\\text{متوسط التغير} = \\\\frac{\\\\Delta ص}{\\\\Delta س}"
}

8. The text and latex fields must represent exactly the same
   mathematics.

9. For blocks that are NOT equations, set:

   "latex": ""

10. If you cannot confidently identify a mathematical symbol,
    use [UNCLEAR] rather than guessing.

============================================================
CRITICAL: TEXT DIRECTION
============================================================

Arabic must be written in LOGICAL order - the order the words
would be typed or spoken - NOT in the visual left-to-right
order the glyphs appear in on the page.

Correct:   متوسط التغير
Wrong:     ريغتلا طسوتم

If you output the second form the transcription is unusable.

============================================================
CRITICAL: NEGATIVE NUMBERS
============================================================

This textbook marks a negative number with a RAISED minus
placed BEFORE the digit:

    the raised form of  1  means  negative one
    the raised form of  6  means  negative six

It is NOT decoration and NOT a footnote marker. It changes the
value of the number.

Always transcribe it as an ordinary minus attached to the
number, for example  -1  and  -6 .

NEVER drop it. A dropped sign turns a correct solution into a
wrong one, and nothing downstream can detect the error.

Before you finish, re-check every result line of every solution
for a raised minus.

============================================================
CRITICAL: EXPONENTS AND INDICES
============================================================

Distinguish carefully between a RAISED digit (an exponent) and
a LOWERED digit (an index):

    raised digit   ->  write as  ^n     (a power)
    lowered digit  ->  write as  _n     (a subscript)

So a variable cubed is written  x^3 , and "x sub 1" is  x_1 .

Read the digit carefully. 2 and 3 are easy to confuse at small
sizes; look closely before deciding.

============================================================
READING ORDER WITHIN A PAGE
============================================================

Follow the page's educational reading order, not the raw
position of text boxes:

- Arabic flows right to left, then top to bottom.
- A label in the right margin (such as an activity, example or
  solution label) belongs WITH the block it labels, as the
  beginning of that block - not as a separate block.
- Keep a numbered list item's number at the START of its item.

============================================================
BLOCK CLASSIFICATION
============================================================

Divide the page according to its natural textbook structure.

Use only these types:

heading
paragraph
activity
definition
rule
example
exercise
solution
equation
note
list_item
table
figure_caption
other

Maintain the visual reading order using the "order" field.

The first educational block is order 1.
The next is order 2.
Continue sequentially.

============================================================
COMPLETENESS CHECK
============================================================

Before producing the final response, inspect the page again.

Verify:

- Did you include every visible educational section?
- Did you miss any line?
- Did you preserve all Arabic text?
- Did you preserve all numbers?
- Did you preserve every equation?
- Did you preserve mathematical signs?
- Did you preserve examples?
- Did you preserve solutions?
- Is the block order correct?

If something visible was omitted, add it before returning the
final result.

Return only the structured document data requested by the
provided JSON schema.
"""


# ============================================================
# Function: render_page_to_base64
#
# Purpose:
# Render one PDF page exactly as it visually appears and
# convert it into a Base64 PNG that Ollama can receive.
#
# Parameters:
# pdf_path:
#     Path to the PDF file.
#
# page_number:
#     PDF page number starting from 1.
#
# Return:
# Base64-encoded PNG image.
# ============================================================

def render_page_to_base64(pdf_path, page_number, dpi=None):

    pdf_path = Path(pdf_path)

    # --------------------------------------------------------
    # Validate the file.
    # --------------------------------------------------------

    if not pdf_path.exists():
        raise FileNotFoundError(
            f"PDF was not found: {pdf_path}"
        )

    if pdf_path.suffix.lower() != ".pdf":
        raise ValueError(
            f"Expected a PDF file: {pdf_path}"
        )

    document = pymupdf.open(pdf_path)

    try:

        # ----------------------------------------------------
        # Validate page number.
        # ----------------------------------------------------

        if (
            page_number < 1
            or page_number > document.page_count
        ):
            raise ValueError(
                f"Page {page_number} does not exist. "
                f"The PDF contains "
                f"{document.page_count} pages."
            )

        # PyMuPDF page indexes begin at zero.
        page_index = page_number - 1

        page = document[page_index]

        # ----------------------------------------------------
        # Render the visual page.
        #
        # We intentionally do NOT use page.get_text()
        # because the source textbook has a corrupted text
        # layer.
        # ----------------------------------------------------

        pixmap = page.get_pixmap(
            dpi=dpi or PAGE_DPI,
            alpha=False,
        )

        # Convert rendered page to PNG bytes.
        image_bytes = pixmap.tobytes("png")

        # Ollama REST API expects images as Base64.
        image_base64 = base64.b64encode(
            image_bytes
        ).decode("utf-8")

        return image_base64

    finally:

        document.close()


# ============================================================
# Function: parse_qwen_json
#
# Purpose:
# Convert Qwen's JSON response string into a Python dictionary
# and validate the minimum structure required by Nipras.
#
# Parameters:
# raw_response:
#     Raw response string returned by Ollama.
#
# Return:
# Parsed Python dictionary.
# ============================================================

def parse_qwen_json(raw_response):

    cleaned_response = raw_response.strip()

    if not cleaned_response:
        raise ValueError(
            "Qwen returned an empty response."
        )

    # --------------------------------------------------------
    # Defensive cleanup.
    #
    # Structured Output should already return JSON.
    # However, this protects us if a model unexpectedly adds
    # Markdown fences.
    # --------------------------------------------------------

    if cleaned_response.startswith("```json"):
        cleaned_response = cleaned_response[7:]

    elif cleaned_response.startswith("```"):
        cleaned_response = cleaned_response[3:]

    if cleaned_response.endswith("```"):
        cleaned_response = cleaned_response[:-3]

    cleaned_response = cleaned_response.strip()

    try:

        document_data = json.loads(
            cleaned_response
        )

    except json.JSONDecodeError as error:

        raise ValueError(
            "Qwen returned invalid JSON."
        ) from error

    # --------------------------------------------------------
    # Basic structure validation.
    # --------------------------------------------------------

    if "blocks" not in document_data:
        raise ValueError(
            "Qwen JSON does not contain a 'blocks' field."
        )

    if not isinstance(
        document_data["blocks"],
        list
    ):
        raise ValueError(
            "The Qwen 'blocks' field must be a list."
        )

    # --------------------------------------------------------
    # Repair visual-order Arabic.
    #
    # Qwen writes Arabic in the order the glyphs appear on the
    # page (left to right) rather than in logical order. Adding
    # explicit instructions to TRANSCRIPTION_PROMPT changed
    # nothing - the output stayed identical character for
    # character - so this is a property of how the vision
    # encoder reads the script, not an instruction the model
    # can follow. It has to be corrected after the fact.
    #
    # The repair is a no-op when the page already comes back in
    # logical order, so it is safe to run unconditionally.
    # --------------------------------------------------------

    document_data, repair_report = repair_document(document_data)

    document_data["bidi_repaired"] = repair_report.get("repaired", False)

    return document_data


# ============================================================
# Function: json_blocks_to_text
#
# Purpose:
# Convert structured Qwen JSON into clean plain text.
#
# This is the important bridge between:
#
# Qwen JSON
#     ↓
# Plain educational text
#     ↓
# chunker.py
#     ↓
# embedding_model.py
#
# JSON keys such as "type", "order", and "latex" are NOT
# inserted into the normal TXT output.
#
# Parameters:
# document_data:
#     Parsed Qwen JSON dictionary.
#
# Return:
# Clean page text.
# ============================================================

def json_blocks_to_text(document_data):

    blocks = document_data.get(
        "blocks",
        []
    )

    # --------------------------------------------------------
    # Sort by the reading order Qwen assigned.
    # --------------------------------------------------------

    sorted_blocks = sorted(
        blocks,
        key=lambda block: block.get(
            "order",
            999999
        )
    )

    text_parts = []

    for block in sorted_blocks:

        block_text = str(
            block.get(
                "text",
                ""
            )
        ).strip()

        # ----------------------------------------------------
        # Normally every equation has a Unicode text field.
        #
        # If Qwen somehow leaves it empty but provides LaTeX,
        # we use LaTeX as a fallback so the equation is not
        # silently lost.
        # ----------------------------------------------------

        if not block_text:

            latex_text = str(
                block.get(
                    "latex",
                    ""
                )
            ).strip()

            if latex_text:
                block_text = latex_text

        # ----------------------------------------------------
        # Only actual educational content goes into TXT.
        # ----------------------------------------------------

        if block_text:
            text_parts.append(
                block_text
            )

    # Separate natural textbook blocks with a blank line.
    clean_text = "\n\n".join(
        text_parts
    )

    return clean_text


# ============================================================
# Function: extract_page_with_qwen
#
# Purpose:
# Perform the complete Qwen3.6 visual extraction process for
# one PDF page.
#
# Workflow:
#
# PDF
# ↓
# Render page
# ↓
# Base64 image
# ↓
# Ollama API
# ↓
# Qwen3.6
# ↓
# Structured JSON
# ↓
# Clean TXT
#
# Parameters:
# pdf_path:
#     Path to PDF.
#
# page_number:
#     PDF page number starting from 1.
#
# Return:
# Dictionary containing:
# - structured document
# - clean text
# - model information
# - performance measurements
# ============================================================

def extract_page_with_qwen(
    pdf_path,
    page_number,
    dpi=None,
    timeout=None,
):

    print(
        f"Rendering PDF page {page_number}..."
    )

    image_base64 = render_page_to_base64(
        pdf_path,
        page_number,
        dpi=dpi,
    )

    print(
        f"Sending page {page_number} "
        f"to {VISION_MODEL_NAME}..."
    )

    # --------------------------------------------------------
    # Ollama request.
    # --------------------------------------------------------

    payload = {

        "model": VISION_MODEL_NAME,

        "prompt": TRANSCRIPTION_PROMPT,

        "images": [
            image_base64
        ],

        # This is transcription, not reasoning.
        "think": False,

        # Return one completed JSON response.
        "stream": False,

        # Ask Ollama to enforce our JSON structure.
        "format": OUTPUT_SCHEMA,

        # Keep Qwen loaded for later page requests.
        "keep_alive": "10m",

        "options": {

            # Extraction should be deterministic.
            "temperature": 0,

            # Test larger context than previous 4096.
            "num_ctx": CONTEXT_SIZE,
        }
    }

    try:

        response = requests.post(
            OLLAMA_URL,
            json=payload,
            timeout=timeout or REQUEST_TIMEOUT_SECONDS,
        )

        response.raise_for_status()

    except requests.exceptions.ConnectionError as error:

        raise RuntimeError(
            "Could not connect to Ollama. "
            "Make sure Ollama is running."
        ) from error

    except requests.exceptions.Timeout as error:

        raise RuntimeError(
            "Qwen extraction timed out."
        ) from error

    except requests.exceptions.HTTPError as error:

        try:

            ollama_error = (
                response.json().get(
                    "error",
                    str(error)
                )
            )

        except ValueError:

            ollama_error = str(error)

        raise RuntimeError(
            f"Ollama API error: {ollama_error}"
        ) from error

    # --------------------------------------------------------
    # Ollama response.
    # --------------------------------------------------------

    result = response.json()

    raw_response = result.get(
        "response",
        ""
    ).strip()

    # --------------------------------------------------------
    # Convert model response into structured Python data.
    # --------------------------------------------------------

    document_data = parse_qwen_json(
        raw_response
    )

    # --------------------------------------------------------
    # Convert structured JSON into plain clean text.
    # --------------------------------------------------------

    clean_text = json_blocks_to_text(
        document_data
    )

    # --------------------------------------------------------
    # Ollama duration values are returned in nanoseconds.
    # Convert them to seconds for easier benchmarking.
    # --------------------------------------------------------

    total_duration_seconds = (
        result.get(
            "total_duration",
            0
        )
        / 1_000_000_000
    )

    load_duration_seconds = (
        result.get(
            "load_duration",
            0
        )
        / 1_000_000_000
    )

    prompt_duration_seconds = (
        result.get(
            "prompt_eval_duration",
            0
        )
        / 1_000_000_000
    )

    generation_duration_seconds = (
        result.get(
            "eval_duration",
            0
        )
        / 1_000_000_000
    )

    return {

        "source": Path(
            pdf_path
        ).name,

        "page_number": page_number,

        "model": VISION_MODEL_NAME,

        # Original JSON text returned by Qwen.
        "raw_response": raw_response,

        # Parsed structured document.
        "document": document_data,

        # Clean educational text generated from JSON.
        "text": clean_text,

        # Performance information.
        "total_duration_seconds":
            total_duration_seconds,

        "load_duration_seconds":
            load_duration_seconds,

        "prompt_duration_seconds":
            prompt_duration_seconds,

        "generation_duration_seconds":
            generation_duration_seconds,

        "input_tokens":
            result.get(
                "prompt_eval_count",
                0
            ),

        "output_tokens":
            result.get(
                "eval_count",
                0
            ),
    }