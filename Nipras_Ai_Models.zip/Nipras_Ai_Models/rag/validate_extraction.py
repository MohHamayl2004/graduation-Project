# ============================================================
# FileName: validate_extraction.py
# Project: Nipras AI Tutor
#
# Purpose:
# Score a real Qwen extraction against a human-checked
# reference page, and flag chunks that cannot be answered from
# text alone.
#
# Why this exists:
# The vision model is the FIRST step of the pipeline. If it
# drops a number or misreads a sign, every later stage -
# chunking, retrieval, the tutor's explanation - is confidently
# wrong, and nothing downstream can detect it.
#
# Usage:
#     python -m rag.validate_extraction \
#         --extracted data/processed/lesson1_page1.json \
#         --reference data/eval/reference_lesson1_page1.json
# ============================================================


import json
import argparse
import re
from pathlib import Path

from rag.normalize import normalize


# Blocks whose meaning depends on a figure that plain text
# cannot carry. A question retrieved without its diagram makes
# the tutor invent values.
FIGURE_DEPENDENT = re.compile(
    r"الشكل\s+المجاور|الرسم\s+المجاور|المنحنى\s+المجاور"
    r"|من\s+الرسم|الشكل\s+الآتي|الشكل\s+التالي"
)

# Blocks the student is meant to fill in - they have no answer
# in the book and must not be indexed as complete material.
INCOMPLETE = re.compile(r"\.{4,}|…{2,}|أكمل")

UNCLEAR = re.compile(r"\[UNCLEAR\]")


# ============================================================
# Function: load_blocks
# ============================================================

def load_blocks(path):

    data = json.loads(
        Path(path).read_text(encoding="utf-8")
    )

    # extract_page_with_qwen returns a wrapper carrying timings and
    # the raw response, with the parsed page under "document".
    # A hand-written reference file holds "blocks" at the top level.
    if "blocks" not in data and isinstance(data.get("document"), dict):

        blocks = data["document"].get("blocks", [])

        merged = dict(data)

        merged["blocks"] = blocks

        return merged, blocks

    return data, data.get("blocks", [])


# ============================================================
# Function: fact_coverage
#
# Purpose:
# Check that every critical fact from the reference survived
# extraction. A missing number is far more damaging than a
# missing adjective, so facts are checked individually.
# ============================================================

def fact_coverage(extracted_blocks, facts):

    # add_latin_math=False on BOTH sides: the Latin copy is a
    # second line, which would break a substring match.
    haystack = normalize(
        " ".join(
            str(block.get("text", ""))
            for block in extracted_blocks
        ),
        add_latin_math=False,
    )

    found = []

    missing = []

    for fact in facts:

        if normalize(fact, add_latin_math=False) in haystack:
            found.append(fact)
        else:
            missing.append(fact)

    return found, missing


# ============================================================
# Function: audit_blocks
#
# Purpose:
# Flag blocks that need special handling before indexing.
# ============================================================

def audit_blocks(blocks):

    needs_figure = []

    incomplete = []

    unclear = []

    for block in blocks:

        text = str(block.get("text", ""))

        if FIGURE_DEPENDENT.search(text):
            needs_figure.append(block.get("order"))

        if INCOMPLETE.search(text):
            incomplete.append(block.get("order"))

        if UNCLEAR.search(text):
            unclear.append(block.get("order"))

    return {
        "needs_figure": needs_figure,
        "incomplete": incomplete,
        "unclear": unclear,
    }


# ============================================================
# Function: validate
# ============================================================

def validate(extracted_path, reference_path=None):

    document, blocks = load_blocks(extracted_path)

    report = {
        "extracted_blocks": len(blocks),
        "audit": audit_blocks(blocks),
    }

    if reference_path:

        reference, reference_blocks = load_blocks(reference_path)

        found, missing = fact_coverage(
            blocks,
            reference.get("critical_facts", []),
        )

        total = len(found) + len(missing)

        report["reference_blocks"] = len(reference_blocks)

        report["block_count_delta"] = len(blocks) - len(reference_blocks)

        report["fact_coverage"] = (
            round(len(found) / total, 3) if total else None
        )

        report["missing_facts"] = missing

    return report


def main():

    parser = argparse.ArgumentParser()
    parser.add_argument("--extracted", required=True)
    parser.add_argument("--reference", default=None)
    args = parser.parse_args()

    report = validate(args.extracted, args.reference)

    print(json.dumps(report, ensure_ascii=False, indent=2))

    coverage = report.get("fact_coverage")

    if coverage is not None and coverage < 1.0:
        print(
            "\nWARNING: the vision model dropped or altered "
            "critical facts. Do NOT index this output - raise "
            "PAGE_DPI or revise TRANSCRIPTION_PROMPT first."
        )

    audit = report["audit"]

    if audit["needs_figure"]:
        print(
            f"\nBlocks {audit['needs_figure']} depend on a figure. "
            "Indexing them as text alone will make the tutor "
            "invent values - attach a description or exclude them."
        )

    if audit["incomplete"]:
        print(
            f"\nBlocks {audit['incomplete']} are fill-in activities "
            "with no answer in the book."
        )


if __name__ == "__main__":
    main()
