# ============================================================
# FileName: embedding_model.py
# Project: Nipras AI Tutor
# LastModifier: Tareq
# LastModifiedDate: 2026-08-15
#
# Purpose:
# Convert lesson text and student questions into numerical
# embedding vectors.
#
#
# Example:
#
# "ما هو العدد الصحيح؟"
#
#       ↓
#
# Embedding Model
#
#       ↓
#
# [0.12, -0.31, 0.08, ...]
#
#
# These vectors allow FAISS to compare the meaning of text.
# ============================================================


import numpy as np

from sentence_transformers import SentenceTransformer

from rag.config import (
    EMBEDDING_MODEL_NAME,
    EMBEDDING_MAX_TOKENS,
    QUERY_PREFIX,
    PASSAGE_PREFIX,
)

from rag.normalize import normalize


# ============================================================
# Class: EmbeddingModel
#
# Purpose:
# Manage the SentenceTransformer embedding model.
#
# Using a class lets us load the model once and reuse it for
# lesson chunks and student questions.
# ============================================================

class EmbeddingModel:


    # ========================================================
    # Function: __init__
    #
    # Purpose:
    # Automatically load the embedding model when we create
    # an EmbeddingModel object.
    #
    #
    # Variable:
    #
    # self.model:
    #     The actual SentenceTransformer model.
    # ========================================================

    def __init__(self):

        print(
            "Loading embedding model..."
        )


        self.model = SentenceTransformer(
            EMBEDDING_MODEL_NAME
        )


        # ----------------------------------------------------
        # Make the truncation limit explicit instead of relying
        # on whatever the checkpoint happens to ship with.
        # Anything longer is cut off silently by the library.
        # ----------------------------------------------------

        self.model.max_seq_length = EMBEDDING_MAX_TOKENS


        print(
            "Embedding model loaded successfully."
        )


    # ========================================================
    # Function: encode_documents
    #
    # Purpose:
    # Convert many lesson chunks into embedding vectors.
    #
    #
    # Parameter:
    #
    # texts:
    #     List of text chunks.
    #
    #
    # Return:
    #
    # embeddings:
    #     NumPy array containing one vector for each chunk.
    # ========================================================

    def encode_documents(self, texts):


        # ----------------------------------------------------
        # embeddings
        #
        # Each text chunk becomes one numerical vector.
        #
        # normalize_embeddings=True makes vectors suitable
        # for cosine-like similarity using FAISS IndexFlatIP.
        # ----------------------------------------------------

        # ----------------------------------------------------
        # THE GOLDEN RULE
        #
        # Documents and questions must pass through the exact
        # same normalization. It is applied here, inside the
        # model wrapper, so no caller can forget it.
        # ----------------------------------------------------

        prepared = [
            PASSAGE_PREFIX + normalize(text)
            for text in texts
        ]


        embeddings = self.model.encode(
            prepared,
            normalize_embeddings=True,
            show_progress_bar=True
        )


        # ----------------------------------------------------
        # FAISS expects vectors in float32 format.
        # ----------------------------------------------------

        embeddings = np.asarray(
            embeddings,
            dtype="float32"
        )


        return embeddings


    # ========================================================
    # Function: encode_query
    #
    # Purpose:
    # Convert one student's question into a vector.
    #
    #
    # Parameter:
    #
    # question:
    #     Student question as normal text.
    #
    #
    # Return:
    #
    # question_embedding:
    #     Numerical vector representing the question.
    # ========================================================

    def encode_query(self, question):


        # ----------------------------------------------------
        # We put question inside [] because SentenceTransformer
        # expects a collection of texts.
        # ----------------------------------------------------

        # Same normalization as encode_documents - see the
        # golden rule in rag/normalize.py.

        prepared = QUERY_PREFIX + normalize(question)


        question_embedding = self.model.encode(
            [prepared],
            normalize_embeddings=True
        )


        question_embedding = np.asarray(
            question_embedding,
            dtype="float32"
        )


        return question_embedding