# ============================================================
# FileName: retriever.py
# Project: Nipras AI Tutor
#
# Purpose:
# Search FAISS and retrieve the lesson chunks that are most
# similar to the student's question.
#
# Question
#    v
# Normalized question  (same normalization used at index time)
#    v
# Metadata filter      (only this subject / unit / source)
#    v
# FAISS - CANDIDATE_K  (a wide net, not the final answer)
#    v
# MMR diversity        (no three copies of the same example)
#    v
# TOP_K chunks
# ============================================================


import numpy as np

from rag.config import (
    TOP_K,
    CANDIDATE_K,
    MMR_LAMBDA,
    DUPLICATE_SIMILARITY,
)


# ============================================================
# Function: passes_filter
#
# Purpose:
# Decide whether a chunk is allowed to be retrieved at all.
#
# Without this, a math question can retrieve physics chunks
# simply because their wording happens to be similar. Filtering
# on metadata removes whole categories of wrong results before
# similarity is even considered.
#
# Parameters:
# chunk:
#     One chunk dictionary from metadata.json.
#
# filters:
#     Dictionary such as {"subject": "math", "unit": 1}.
#     A value may also be a list, meaning "any of these".
#
# Return:
# True when the chunk satisfies every filter.
# ============================================================

def passes_filter(chunk, filters):

    if not filters:
        return True

    for key, wanted in filters.items():

        if wanted is None:
            continue

        actual = chunk.get(key)

        if isinstance(wanted, (list, tuple, set)):

            if actual not in wanted:
                return False

        elif actual != wanted:
            return False

    return True


# ============================================================
# Function: maximal_marginal_relevance
#
# Purpose:
# Choose results that are relevant to the question AND
# different from each other.
#
# Plain top-k by similarity often returns the same example
# three times (the book copy, the helper copy and the exam
# copy). Those three slots carry the information of one slot,
# and the tutor loses the context it actually needed.
#
# Parameters:
# question_vector:
#     Normalized embedding of the student question.
#
# candidate_vectors:
#     Embeddings of the candidate chunks.
#
# candidate_scores:
#     Similarity of each candidate to the question.
#
# k:
#     How many results to keep.
#
# Return:
# Indices of the selected candidates, best first.
# ============================================================

def maximal_marginal_relevance(
    question_vector,
    candidate_vectors,
    candidate_scores,
    k,
):

    if len(candidate_vectors) == 0:
        return []

    selected = []

    remaining = list(range(len(candidate_vectors)))

    while remaining and len(selected) < k:

        best_index = None

        best_value = -1e9

        for candidate in remaining:

            relevance = candidate_scores[candidate]

            # --------------------------------------------
            # Penalise a candidate that is too close to
            # something already selected.
            # --------------------------------------------

            if selected:

                redundancy = max(
                    float(
                        np.dot(
                            candidate_vectors[candidate],
                            candidate_vectors[chosen],
                        )
                    )
                    for chosen in selected
                )

            else:
                redundancy = 0.0

            # Drop outright duplicates.
            if redundancy >= DUPLICATE_SIMILARITY:
                continue

            value = (
                MMR_LAMBDA * relevance
                - (1.0 - MMR_LAMBDA) * redundancy
            )

            if value > best_value:
                best_value = value
                best_index = candidate

        if best_index is None:
            break

        selected.append(best_index)

        remaining.remove(best_index)

    return selected


# ============================================================
# Function: retrieve
#
# Purpose:
# Search the vector database for information related to the
# student's question.
#
# Parameters:
# question:
#     Student's question as normal text.
#
# embedding_model:
#     EmbeddingModel object.
#
# index:
#     FAISS vector index.
#
# chunks:
#     Chunk dictionaries, in the SAME order as the vectors.
#
# filters:
#     Optional metadata restriction, e.g. {"subject": "math"}.
#
# top_k:
#     Optional override of the configured TOP_K.
#
# Return:
# List of retrieved chunk dictionaries, best first.
# ============================================================

def retrieve(
    question,
    embedding_model,
    index,
    chunks,
    filters=None,
    top_k=None,
):

    if not question or not str(question).strip():
        return []

    if not chunks:
        return []

    # --------------------------------------------------------
    # SAFETY CHECK
    #
    # FAISS returns positions, and we look those positions up
    # in the chunks list. If the two ever fall out of step, the
    # system quietly answers using the WRONG chunk - the single
    # most dangerous failure mode in a RAG pipeline, because
    # nothing crashes and the answer still looks plausible.
    # --------------------------------------------------------

    if index.ntotal != len(chunks):

        raise RuntimeError(
            "Vector/metadata mismatch: FAISS holds "
            f"{index.ntotal} vectors but metadata holds "
            f"{len(chunks)} chunks. The database must be "
            "rebuilt - results would map to the wrong text."
        )

    final_k = top_k or TOP_K

    question_embedding = embedding_model.encode_query(
        question
    )

    # --------------------------------------------------------
    # Pull a wide candidate set first, because the metadata
    # filter and the diversity step will both discard some of
    # it. Asking FAISS for only TOP_K would leave us short.
    # --------------------------------------------------------

    candidate_k = min(
        max(CANDIDATE_K, final_k),
        len(chunks),
    )

    scores, indices = index.search(
        question_embedding,
        candidate_k,
    )

    candidate_positions = []

    candidate_scores = []

    for rank, position in enumerate(indices[0]):

        if position < 0:
            continue

        chunk = chunks[position]

        if not passes_filter(chunk, filters):
            continue

        candidate_positions.append(int(position))

        candidate_scores.append(float(scores[0][rank]))

    if not candidate_positions:
        return []

    # --------------------------------------------------------
    # Rebuild the candidate vectors so redundancy between
    # candidates can be measured.
    # --------------------------------------------------------

    candidate_vectors = np.vstack(
        [
            index.reconstruct(position)
            for position in candidate_positions
        ]
    )

    chosen = maximal_marginal_relevance(
        question_embedding[0],
        candidate_vectors,
        candidate_scores,
        final_k,
    )

    results = []

    for order, candidate in enumerate(chosen):

        position = candidate_positions[candidate]

        chunk = chunks[position]

        results.append(
            {
                "rank": order + 1,

                "chunk_id": chunk.get("chunk_id"),

                "text": chunk.get("text", ""),

                "source": chunk.get("source"),

                "page_number": chunk.get("page_number"),

                "subject": chunk.get("subject"),

                "lesson": chunk.get("lesson"),

                "block_types": chunk.get("block_types", []),

                "truncation_risk": chunk.get(
                    "truncation_risk",
                    False,
                ),

                "score": candidate_scores[candidate],
            }
        )

    return results
