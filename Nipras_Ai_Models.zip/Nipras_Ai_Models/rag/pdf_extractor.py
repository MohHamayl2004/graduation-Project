# ============================================================
# FileName: pdf_extractor.py
# Project: Nipras AI Tutor
# LastModifier: Tareq
# LastModifiedDate: 2026-08-15
#
# Purpose:
# Open PDF lesson files and extract text from every page.
#
# Input:
# PDF file path.
#
# Output:
# A list containing:
#
# - PDF source name
# - page number
# - extracted page text
# ============================================================


from pathlib import Path

import pymupdf


# ============================================================
# Function: extract_pdf
#
# Purpose:
# Extract text from one PDF file.
#
# Parameter:
#
# pdf_path:
#     Location of the PDF file.
#
# Example:
#
# data/math_lesson_1.pdf
#
#
# Return:
#
# pages:
#     A list of dictionaries.
#
# Example:
#
# [
#     {
#         "source": "math_lesson_1.pdf",
#         "page_number": 1,
#         "text": "..."
#     }
# ]
# ============================================================

def extract_pdf(pdf_path):

    # --------------------------------------------------------
    # Convert pdf_path into a Path object.
    #
    # This makes file operations easier and lets us use
    # properties such as pdf_path.name.
    # --------------------------------------------------------

    pdf_path = Path(pdf_path)


    # --------------------------------------------------------
    # doc
    #
    # Meaning:
    # Represents the opened PDF document.
    #
    # PyMuPDF gives us access to every page through this
    # object.
    # --------------------------------------------------------

    doc = pymupdf.open(pdf_path)


    # --------------------------------------------------------
    # pages
    #
    # Meaning:
    # This list will contain the extracted information from
    # every page.
    # --------------------------------------------------------

    pages = []


    # --------------------------------------------------------
    # enumerate(doc)
    #
    # enumerate gives us two values:
    #
    # page_number:
    #     Position of the page.
    #
    # page:
    #     The actual PyMuPDF page object.
    #
    # Python starts counting from 0.
    # --------------------------------------------------------

    for page_number, page in enumerate(doc):


        # ----------------------------------------------------
        # page_text
        #
        # Meaning:
        # Text extracted from the current PDF page.
        #
        # sort=True asks PyMuPDF to try to return text in a
        # more natural reading order.
        # ----------------------------------------------------

        page_text = page.get_text(
            "text",
            sort=True
        )


        # ----------------------------------------------------
        # If no useful text exists on this page, skip it.
        #
        # This prevents empty pages from creating useless
        # chunks later.
        # ----------------------------------------------------

        if not page_text.strip():
            continue


        # ----------------------------------------------------
        # Store:
        #
        # source:
        #     PDF filename.
        #
        # page_number:
        #     Human-readable page number.
        #
        # text:
        #     Extracted text.
        # ----------------------------------------------------

        pages.append(
            {
                "source": pdf_path.name,

                "page_number": page_number + 1,

                "text": page_text
            }
        )


    # Close the file after extraction.
    doc.close()


    # Return all extracted pages.
    return pages